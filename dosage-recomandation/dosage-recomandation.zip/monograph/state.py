last_state = {
    "monograph_hash": None,
    "full_text": "",
    "tables": "",
    "tables_html": "",
    "report": None,
    "patient": None,
    "drug_name": "",
    "patient_bio": None,
    "patient_bio_polished": None,
    "patient_bio_html": None,
    "patient_bio_readable": None,
    "case_summary": None,
    "full_ai_report": None,
    "dashboard_html": None,
    "narrative_one_paragraph": None
}
